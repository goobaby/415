### Amit Deb and Luke Demeter-Willison proudly present
# Project 2a
### With both extra credit elements implemented

## Running the project
![ferris :)](https://rustacean.net/assets/cuddlyferris.svg)
This is a Rust project (and has no dependencies!), so it's pretty straightforward to run. 

1) Go to [rust-lang.org/learn/get-started](https://www.rust-lang.org/learn/get-started)

2) Download & install Rustup

3) Navigate to the root folder of this project on your terminal of choice

4) Run the following on said terminal: `cargo run -r`

5) Voila! The program should run shortly afterward