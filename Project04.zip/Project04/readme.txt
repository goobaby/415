Project 4, by Luke Demeter-Willison and Amit Deb

Installation instructions:
    This uses python 3 which you can get at:
        https://www.python.org/
    The only other package needed, which after getting python can be installed via:
        pip install numpy
    