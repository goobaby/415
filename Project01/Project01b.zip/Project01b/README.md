Names : Amit Deb and Luke Demeter-Wilison

Instructions:

    Install python if not already installed on machine

    Install matplotlib if not already installed on machine, with the following commands

        python -m pip install -U pip
        python -m pip install -U matplotlib

    Change the current working directory to the directory that contains main.py and this README.md

    Once there type

        python main.py

    Follow the instructions on terminal to run the necessary tasks

    The program will stop once a task has been completed, please run it again to run other tasks